import React from 'react';
import { Container, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

import CorpoRegistro from '../components/TelaCadastro/CorpoRegistro';

const TelaCadastro = () => {
  return (
    <>
      <CorpoRegistro/>
    </>


  );
};

export default TelaCadastro;
