import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // Importa o CSS do Bootstrap
import { PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import { FaTrophy } from 'react-icons/fa';
import InfoPerfil from './InfoPerfil';
import Grafico from './Grafico';
import { CiLogout } from "react-icons/ci";
import { useNavigate } from 'react-router-dom';




const CardPerfil = ({ nome, escola, img, periodo, token, navigate }) => {

  const logout = () => {
    Swal.fire({
      title: "Deseja sair??",
      showDenyButton: true,
      confirmButtonText: "Desconectar minha conta",
      denyButtonText: `Voltar`
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        localStorage.removeItem('token')
        navigate("/login")
      }
    });
  }



  return (
    <div className="col-12 text-dark mt-3 p-3 shadow-sm mt-2">
      <div className='justify-content-end fs-1 d-flex'>
        <CiLogout onClick={logout} />
      </div>
      <div className="row">
        <div className="col-2">
          <img src={'http://localhost:3025/public/' + img} className="img-fluid rounded-circle" alt="User" />
        </div>
        <InfoPerfil nome={nome} periodo={periodo} escola={escola}></InfoPerfil>
        
      </div>
    </div>
  );
};

export default CardPerfil;
