import React, { useEffect, useState } from 'react';
import axios from 'axios';
export const urlJogos = "http://localhost:3025/api/jogos";
import { SwalErroToken } from '../../TelaPerfil/SwalError';

// Variavel necessaria para o SweetAlert2

const swalWithBootstrapButtons = Swal.mixin({
    customClass: {
        confirmButton: "btn btn-success",
        cancelButton: "btn btn-danger"
    },
    buttonsStyling: false
});

// Função de abrir a tela de edição de items

// Função de abrir a tela de edição de itens
export const ModalEditJogos = (id,navigate,token) => {
    swalWithBootstrapButtons.fire({
        title: "Edit User",
        text: "Here you can edit user details.",
        icon: "info"
    });
};

// Função de abrir modal para deletar arquivos
export const ModalDeleteJogos = (id, atualizar,navigate,token) => {
    swalWithBootstrapButtons.fire({
        title: "Tem certeza?",
        text: "Você não podera reverter isto!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Sim, deletar!",
        cancelButtonText: "Não, cancelar!",
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            deletarJogos(id, atualizar,navigate,token);
        } else if (result.dismiss === Swal.DismissReason.cancel) {
            swalWithBootstrapButtons.fire({
                title: "Cancelado",
                text: "Seus arquivos estão seguros",
                icon: "error"
            });
        }
    });
};




export const useImportarDadosJogos = (token, navigate) => {
    const [TableJogos, setTableJogos] = useState([])
    async function atualizar() {
        try {
            let resposta = await axios.get(urlJogos, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            setTableJogos(resposta.data)
        } catch (error) {
            SwalErroToken(navigate)
        }
    }

    useEffect(() => {
        atualizar()
    }, [])

    return {
        TableJogos,
        atualizar
    }
}

export const formatarData = (dataString) => {
    const data = new Date(dataString);
    const novoModelo = `${data.getDate().toString().padStart(2, '0')}/${(data.getMonth() + 1).toString().padStart(2, '0')}/${data.getFullYear()}`;
    return novoModelo;
};

// Deletar Escola específica
export const deletarJogos = async (id, atualizar,navigate,token) => {
    try {
        let resposta = await axios.delete(`${urlJogos}/${id}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        if (!resposta.data.status) {
            console.log("Não foi excluído");
            swalWithBootstrapButtons.fire({
                title: "Falhou!",
                html: "Seu jogo não foi deletado!<br> <br> Código do erro: " + resposta.data.error.code,
                icon: "error"
            });
        } else {
            atualizar(); // Atualiza a lista após a exclusão
            swalWithBootstrapButtons.fire({
                title: "Deleted!",
                text: "Seu jogo foi deletado!",
                icon: "success"
            });
            console.log("Excluído");
        }
    } catch (error) {
        SwalErroToken(navigate)
    }
};

