import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // Importa o CSS do Bootstrap
import CorpoLogin from '../components/TelaLogin/CorpoLogin';



const TelaLogin = () => {
  return (
    <>
        <CorpoLogin></CorpoLogin>
    </>
  );
};

export default TelaLogin;
