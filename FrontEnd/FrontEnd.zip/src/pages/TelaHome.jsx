import React from 'react';
import { Container, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from '../components/TelaHome/Header';
import Corpo from '../components/TelaHome/Corpo';


const TelaHome = () => {
  return (
    <>
    
      <Header/>
      <Corpo></Corpo>
      

    </>


  );
};

export default TelaHome;
