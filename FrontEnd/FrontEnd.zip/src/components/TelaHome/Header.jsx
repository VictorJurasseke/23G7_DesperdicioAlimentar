import React, { useState } from 'react';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  NavbarText,
} from 'reactstrap';

function Header(props) {
  const [isOpen, setIsOpen] = useState(true);

  const toggle = () => setIsOpen(!isOpen);

  return (
    <Navbar className='justify-content-between position-absolute col-12 p-2 z-3' dark expand="lg" {...props}>
      <NavbarBrand className='text-dark d-flex' href='/'>
        <img src='http://localhost:3025/public/LogoEgg.png' style={{ width: "80px" }} alt='logo' />

      </NavbarBrand>
      <NavbarToggler onClick={toggle} />
      <Collapse isOpen={isOpen} navbar>
        <Nav className="ml-auto d-flex  justify-content-end col-12 p-1" navbar>
          <NavItem className="d-flex align-items-center"> {/* Adicione d-flex aqui */}
            <NavLink className='text-dark' href="/list">
              <span className="material-symbols-outlined fs-2">list_alt</span>
            </NavLink>
          </NavItem>

          <NavItem className="d-flex align-items-center"> {/* Adicione d-flex aqui */}
            <NavLink className='text-dark' href="/games">
              <span className="material-symbols-outlined fs-2">sports_esports</span>
            </NavLink>
          </NavItem>

          <NavItem className="d-flex align-items-center"> {/* Adicione d-flex aqui */}
            <NavLink className='text-dark' href="/rank">
              <span className="material-symbols-outlined fs-2">trophy</span>
            </NavLink>
          </NavItem>

          <NavItem className="d-flex align-items-center"> {/* Adicione d-flex aqui */}
            <NavLink className='text-dark' href="/user">
              <span className="material-symbols-outlined fs-2">account_circle</span>
            </NavLink>
          </NavItem>

          <NavItem className="d-flex align-items-center"> {/* Adicione d-flex aqui */}
            <NavLink className='text-dark' href="/devs">
              <span className="material-symbols-outlined fs-2">settings</span>
            </NavLink>
          </NavItem>
        </Nav>

      </Collapse>
    </Navbar>


  );
}

export default Header;
