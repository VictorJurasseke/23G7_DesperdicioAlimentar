const db = require('../../db');

module.exports.retornarTodosJogos = async () => {
    let conexao;
    try {
        conexao = await db.criarConexao();
        const [linhas] = await conexao.execute('SELECT j.ID_jogos, j.jo_nome, j.jo_datai, j.jo_dataf, e.es_nome FROM jogos j, escola e WHERE j.ID_escola = e.ID_escola;');
        return linhas;
    } catch (error) {
        console.error("Erro ao listar todos os jogos", error);
        throw error;
    } finally {
        db.liberarConexao(conexao);
    }
};

module.exports.ApagarJogos = async (id) => {
    let conexao;
    try {
        conexao = await db.criarConexao();

        // Deletar usuários associados à escola

        // Finalmente, deletar a escola
        const [linhas] = await conexao.execute('DELETE FROM jogos WHERE ID_jogos = ?', [id]);
        return { status: true }
    } catch (error) {
        return { status: false, error: error }
        throw error // Repassa para a controller
    } finally {
        db.liberarConexao(conexao)

    }
};



module.exports.ParticiparJogo = async (ID_usuarios, ID_jogos) => {
    let conexao;
    try {
        conexao = await db.criarConexao();

        // Inserir o ID_jogos e ID_usuarios na tabela jogos_matricula, com pontos_usuario e rank_usuario inicializados a 0
        const [linhas] = await conexao.execute(
            'INSERT INTO jogos_matricula (ID_jogos, ID_usuarios, pontos_usuario, rank_usuario) VALUES (?, ?, 0, 0)',
            [ID_jogos, ID_usuarios]
        );
        return { status: true };
    } catch (error) {
        return { status: false, error: error };
        throw error; // Repassa para a controller
    } finally {
        db.liberarConexao(conexao);
    }
};

module.exports.atualizarRankingJogo = async (ID_jogos) => {
    let conexao;
    try {
        conexao = await db.criarConexao();

        // Obter a lista de usuários e seus pontos, com a classificação (rank)
        const [resultados] = await conexao.execute(
            `SELECT ID_usuarios, 
                    RANK() OVER (ORDER BY pontos_usuario DESC) AS rank_usuario 
             FROM jogos_matricula 
             WHERE ID_jogos = ?`,
            [ID_jogos]
        );

        // Atualizar o rank de cada usuário com base no resultado obtido
        for (const { ID_usuarios, rank_usuario } of resultados) {
            await conexao.execute(
                'UPDATE jogos_matricula SET rank_usuario = ? WHERE ID_jogos = ? AND ID_usuarios = ?',
                [rank_usuario, ID_jogos, ID_usuarios]
            );
        }

        return { status: true };
    } catch (error) {
        console.error("Erro ao atualizar o ranking do jogo", error);
        return { status: false, error: error };
    } finally {
        db.liberarConexao(conexao);
    }
};
// SQL para Obter Ranking:
// sql
// Copiar código
// SELECT ID_usuarios,
//        RANK() OVER (ORDER BY pontos_usuario DESC) AS rank_usuario
// FROM jogos_matricula
// WHERE ID_jogos = ?;
// Explicação de cada parte:
// SELECT ID_usuarios,:

// Estamos selecionando a coluna ID_usuarios da tabela jogos_matricula, que representa o identificador de cada usuário inscrito em um determinado jogo.
// RANK() OVER (ORDER BY pontos_usuario DESC) AS rank_usuario:

// RANK() é uma função de janela (window function) no SQL. Ela gera um número de classificação (ranking) para cada linha com base em algum critério.
// OVER (ORDER BY pontos_usuario DESC): Isso define a lógica de classificação. Neste caso, estamos ordenando os usuários pelos pontos (pontos_usuario) em ordem decrescente (DESC). Usuários com mais pontos terão um ranking menor (1º, 2º, 3º...).
// AS rank_usuario: Nomeamos o resultado da função RANK() como rank_usuario, que será a posição (rank) de cada usuário com base nos seus pontos.
// FROM jogos_matricula:

// Especifica a tabela de onde estamos extraindo os dados. Aqui, a tabela jogos_matricula contém as informações sobre quais usuários estão inscritos em cada jogo e seus respectivos pontos.
// WHERE ID_jogos = ?:

// A cláusula WHERE filtra os resultados para incluir apenas os usuários inscritos em um jogo específico. O ? é um placeholder que será substituído pelo valor real do ID_jogos no código do Node.js.