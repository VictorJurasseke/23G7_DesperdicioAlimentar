import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // Importa o CSS do Bootstrap
import CardPerfil from '../components/TelaPerfil/CardPerfil';
import Header from '../components/TelaHome/Header';
import Lib from '../components/TelaPerfil/Lib';
import NavbarPets from '../components/TelaPerfil/NavbarPets';
import { usePerfilDados } from '../components/TelaPerfil/FunctionTelaPerfil';
import LoadingComponent from '../components/TelaPerfil/LoadingComponent';
import { useNavigate } from 'react-router-dom';

const TelaPerfil = () => {

    const token = localStorage.getItem("token")
    const navigate = useNavigate()

    const { Dados_usuario } = usePerfilDados(token,navigate); // Agora pode desestruturar corretamente
    console.log("Tela carregada")

    return (
        <>
            {Dados_usuario ? ( // Verifica se Dados_usuario não é null e se o token esta correto
                <>
                    <div className='col-12 d-flex flex-column overflow-hidden text-dark min-vh-100'>
                        <Header />
                        <div style={{ height: "50px" }}></div>
                        <div className='col-12 mt-5 text-dark'>
                            <CardPerfil
                                nome={Dados_usuario.user_nome}
                                periodo={Dados_usuario.user_periodo}
                                escola={Dados_usuario.es_nome}
                                img={Dados_usuario.user_img_caminho}
                                token={token}
                                navigate={navigate}
                            />
                            <div className='text-dark'>
                                <NavbarPets />
                                <Lib />
                            </div>
                        </div>
                    </div>
                </>
            ) : (
                <LoadingComponent /> // Mensagem de carregamento enquanto
                // verifica se o usuario esta logado
            )}
        </>
    );
};

export default TelaPerfil;
