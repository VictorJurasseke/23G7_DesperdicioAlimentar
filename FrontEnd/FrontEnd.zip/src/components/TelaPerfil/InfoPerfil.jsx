import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // Importa o CSS do Bootstrap


const InfoPerfil = ({ nome, periodo, escola}) => {
  return (
        <div className="col-md-4">
          <div className="card-body">
            <h1 className="fs-3 mt-4" >{nome}</h1>
            <p className="card-text">{escola}</p>
            <p className="card-text"><small className="text-body-secondary">{periodo}</small></p>
          </div>
        </div>
  );
};

export default InfoPerfil;
