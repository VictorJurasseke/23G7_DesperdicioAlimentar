const app = require('./src/app')

app.iniciarApp()