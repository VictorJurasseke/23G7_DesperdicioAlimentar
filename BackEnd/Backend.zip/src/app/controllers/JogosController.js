const express = require('express');
const rotas = express.Router();
const model = require("../../app/models/JogosModel");
const verificarToken = require('../middleware/autenticar')



rotas.get('/', verificarToken, async (req, res) => {
    console.log("Requisição recebida em /api/jogos"); // Log
    try {
        const jogos = await model.retornarTodosJogos();
        res.json(jogos);
    } catch (error) {
        console.error("Erro ao listar os jogos", error);
        res.status(500).json({ error: "Erro interno do servidor" });
    }
});

rotas.delete('/:id', verificarToken, async (req, res) => {
    const { id } = req.params
    console.log(id)
    console.log(`Requisição delete em /api/jogos/${id}`); // Log
    try {
        const jogos = await model.ApagarJogos(id);
        res.json(jogos);

    } catch (error) {
        console.error("Erro ao apagar um jogo", error);
        res.status(500).json({ error: "Erro interno do servidor" });
    }
});

rotas.post('/participar/:id', verificarToken, async (req, res) => {
    let ID_jogos = req.params.id
    console.log("Requisição recebida em /api/jogos/:",ID_jogos," no id do usuario" ,req.info.ID_usuarios); // Log
    try {
        const jogos = await model.ParticiparJogo(req.info.ID_usuarios, ID_jogos);
        res.json(jogos);
    } catch (error) {
        console.error("Erro ao tentar participar do jogo", error);
        res.status(500).json({ error: "Erro interno do servidor" });
    }
});


module.exports = rotas;
