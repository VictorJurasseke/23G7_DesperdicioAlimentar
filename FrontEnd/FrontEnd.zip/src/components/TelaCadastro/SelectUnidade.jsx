import React from 'react';

const SelectUnidade = () => {
    return (
      <>
<div className="">
            <label htmlFor="unidade_registrar_escola" className="form-label m-1">Escola - Unidade</label>
            <select
              required
        
              className="form-select form-select-sm"
            >
              <option value={0} disabled>Selecione sua escola:</option>
              <option value={1}>SESI 138 - SANTO ANASTÁCIO</option>
            </select>
          </div>
      </>
    );
  };

export default SelectUnidade;
